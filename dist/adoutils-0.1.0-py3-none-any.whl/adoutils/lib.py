def data_validator():
    print("Hello from Python Package")
